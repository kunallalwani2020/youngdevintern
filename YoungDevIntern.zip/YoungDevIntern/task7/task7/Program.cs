﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQFilterEvenNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize a list of integers
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Console.WriteLine("Original List:");
            Console.WriteLine(string.Join(", ", numbers));

            // Use LINQ to filter out even numbers
            var oddNumbers = numbers.Where(n => n % 2 != 0);

            Console.WriteLine("\nFiltered List (Odd Numbers):");
            Console.WriteLine(string.Join(", ", oddNumbers));

            // Wait for user input before closing the application
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
