﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task5
{
    internal class Program
    {
        class Person
        {
            public string Name;
            public int Age;

            public void DisplayDetail()
            {
                Console.WriteLine($"My name is {Name}");
                Console.WriteLine($"Your age is {Age}");
            }
        }
        static void Main(string[] args)
        {
           Person person = new Person();
            person.Name = "Kunal";
            person.Age = 30;
            person.DisplayDetail();
        }
    }
}
