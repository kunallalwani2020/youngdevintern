﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            Console.WriteLine("Enter 5 integers: ");
            for (int i = 0; i < arr.Length; i++) 
            {
                Console.Write($"Enter value for index {i}: ");
                arr[i] = int.Parse(Console.ReadLine());
            }
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }
}
