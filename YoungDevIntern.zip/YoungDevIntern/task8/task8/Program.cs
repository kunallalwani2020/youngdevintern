﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace AsyncDownloadExample
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting download...");

            // URL to download data from
            string url = "https://www.example.com";

            try
            {
                // Call the asynchronous method to download data
                int dataLength = await DownloadDataAsync(url);

                // Print the length of the downloaded data
                Console.WriteLine($"Data downloaded successfully. Length: {dataLength} bytes.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            // Wait for user input before closing the console
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        /// <summary>
        /// Asynchronously downloads data from the specified URL and returns its length.
        /// </summary>
        /// <param name="url">The URL to download data from.</param>
        /// <returns>The length of the downloaded data.</returns>
        static async Task<int> DownloadDataAsync(string url)
        {
             HttpClient client = new HttpClient();

            // Asynchronously download the data as a string
            string data = await client.GetStringAsync(url);

            // Return the length of the data
            return data.Length;
        }
    }
}
