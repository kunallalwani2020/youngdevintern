﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task9

{
    public class Calculator
    {
        /// <summary>
        /// Adds two integers and returns the result.
        /// </summary>
        public int Add(int a, int b)
        {
            return a + b;
        }
    }
}

