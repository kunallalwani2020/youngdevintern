using SimpleCalculator; // Namespace of the Calculator class
using task9;
using Xunit;

namespace SimpleCalculatorTests
{
    public class CalculatorTests
    {
        [Fact]
        public void Add_TwoPositiveNumbers_ReturnsCorrectSum()
        {
            // Arrange
            var calculator = new Calculator();
            int a = 5;
            int b = 7;

            // Act
            int result = calculator.Add(a, b);

            // Assert
            Assert.Equal(12, result);
        }

        [Fact]
        public void Add_NegativeAndPositiveNumber_ReturnsCorrectSum()
        {
            // Arrange
            var calculator = new Calculator();
            int a = -3;
            int b = 10;

            // Act
            int result = calculator.Add(a, b);

            // Assert
            Assert.Equal(7, result);
        }

        [Fact]
        public void Add_TwoNegativeNumbers_ReturnsCorrectSum()
        {
            // Arrange
            var calculator = new Calculator();
            int a = -4;
            int b = -6;

            // Act
            int result = calculator.Add(a, b);

            // Assert
            Assert.Equal(-10, result);
        }
    }
}
