﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string inputFilePath = "C:\\Users\\DELL\\Desktop\\YoungDevIntern\\Task4 intermediate\\input.txt";
        string outputFilePath = "C:\\Users\\DELL\\Desktop\\YoungDevIntern\\Task4 intermediate\\output.txt";

        try
        {
            // Step 1: Read text from "input.txt"
            if (!File.Exists(inputFilePath))
            {
                Console.WriteLine($"Error: The file \"{inputFilePath}\" does not exist.");
                return;
            }

            string content = File.ReadAllText(inputFilePath);
            Console.WriteLine($"Content of \"{inputFilePath}\":\n{content}");

            // Step 2: Write text to "output.txt"
            File.WriteAllText(outputFilePath, content);
            Console.WriteLine($"\nThe content has been successfully written to \"{outputFilePath}\".");
        }
        catch (Exception ex)
        {
            // Handle unexpected errors
            Console.WriteLine($"An error occurred: {ex.Message}");
        }

        Console.WriteLine("\nPress any key to exit.");
        Console.ReadKey();
    }
}
