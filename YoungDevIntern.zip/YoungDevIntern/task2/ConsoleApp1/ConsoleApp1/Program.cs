﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Operator + ,- ,/,x");
            string op = Console.ReadLine(); 
            switch (op) {
                case "+":
                    Console.WriteLine($"The addition is { a + b}");
                    break;
                    case "-":
                    Console.WriteLine($"The subtraction is {a - b}");
                    break;
                case "/":
                    Console.WriteLine($"The Division is {a / b}");
                    break;
                case "x":
                    Console.WriteLine($"The Multiplication is {a * b}");
                    break;

                default:
                    Console.WriteLine("Invalid ");
                    break;
            }
        }
    }
}
