﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace task6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Ask the user for the first number
                Console.Write("Enter the first number: ");
                double num1 = double.Parse(Console.ReadLine());

                // Ask the user for the second number
                Console.Write("Enter the second number: ");
                double num2 = double.Parse(Console.ReadLine());

                // Perform division and display the result
                double result = num1 / num2;
                Console.WriteLine($"The result of dividing {num1} by {num2} is: {result}");
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Error: Division by zero is not allowed. Please try again with a non-zero divisor.");
            }
            catch (FormatException) { Console.WriteLine("Error: Invalid input. Please enter valid numeric values."); }
            catch (Exception ex)
            {
                // Handle any other exceptions
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
            finally
            {
                // Code in the `finally` block will always run, even if an exception occurs
                Console.WriteLine("Thank you for using the division application!");
            }

        }

    }
}
